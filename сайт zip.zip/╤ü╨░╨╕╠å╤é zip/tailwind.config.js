/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
      './pages/**/*.{js,ts,jsx,tsx}',
      './components/**/*.{js,ts,jsx,tsx}',
    ],
    theme: {
      extend: {
        colors: {
          linen: '#FAF9F6',     // Нежно льняной цвет фона
          pastelLavender: '#DCCEF9',
          pastelMint: '#C2EFE3',
          iosBlue: '#007AFF', // типичный iOS-синий
        },
      },
    },
    plugins: [],
  };