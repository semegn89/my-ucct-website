// components/ProposalCard.tsx
import React from 'react';

interface ProposalCardProps {
  id: number;
  description: string;
  forVotes: number;
  againstVotes: number;
  deadline: number;  // timestamp
}

const ProposalCard: React.FC<ProposalCardProps> = ({
  id,
  description,
  forVotes,
  againstVotes,
  deadline
}) => {
  const deadlineDate = new Date(deadline * 1000).toLocaleString();

  return (
    <div style={{ border: '1px solid #ccc', marginBottom: '1rem', padding: '1rem' }}>
      <h3>Proposal #{id}</h3>
      <p>{description}</p>
      <p>For: {forVotes}, Against: {againstVotes}</p>
      <p>Deadline: {deadlineDate}</p>
      {/* Ссылка на детали */}
    </div>
  );
};

export default ProposalCard;