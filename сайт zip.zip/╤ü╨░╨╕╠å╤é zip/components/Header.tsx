// components/Header.tsx
import React, { useState } from 'react';
import Link from 'next/link';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header
      className="
        sticky top-0 z-50
        bg-white/60
        backdrop-blur-md
        shadow
      "
    >
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="text-xl font-bold text-iosBlue">
          UCCT iOS Style
        </div>
        <nav className="hidden md:flex space-x-4 text-gray-700 font-medium">
          {/* Ваши ссылки */}
          <Link href="/">
            <span className="hover:text-iosBlue cursor-pointer">Dashboard</span>
          </Link>
          <Link href="/profile">
            <span className="hover:text-iosBlue cursor-pointer">Profile</span>
          </Link>
          {/* ...и так далее */}
        </nav>

        {/* Mobile menu button */}
        <button
          className="md:hidden text-gray-700"
          onClick={() => setIsOpen(!isOpen)}
        >
          {/* Иконка */}
          <svg
            className="w-6 h-6"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 6h16M4 12h16M4 18h16"
            />
          </svg>
        </button>
      </div>

      {/* Мобильное меню */}
      {isOpen && (
        <div
          className="
            md:hidden
            bg-white/80
            backdrop-blur-sm
            px-4 pb-4 space-y-2
          "
        >
          <Link href="/">
            <span onClick={() => setIsOpen(false)} className="block hover:text-iosBlue">Dashboard</span>
          </Link>
          <Link href="/profile">
            <span onClick={() => setIsOpen(false)} className="block hover:text-iosBlue">Profile</span>
          </Link>
          {/* ...и остальные */}
        </div>
      )}
    </header>
  );
};

export default Header;