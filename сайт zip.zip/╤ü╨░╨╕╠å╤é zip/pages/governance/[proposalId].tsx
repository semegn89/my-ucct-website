// pages/governance/[proposalId].tsx
import { NextPage } from 'next';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import Layout from '../../components/Layout';
import { getContract, getProvider } from '../../lib/contract';
import { ethers } from 'ethers';

const ProposalDetail: NextPage = () => {
  const router = useRouter();
  const { proposalId } = router.query; // из URL
  const [proposalData, setProposalData] = useState<any>(null);

  const [hasVoted, setHasVoted] = useState(false);

  const fetchProposalData = async (id: string) => {
    // Здесь вы можете вызвать метод контракта по ID предложения
    // В демо мы имитируем данные
    // В реальном случае, например: contract.proposals(id)
    setProposalData({
      id,
      description: "Demo proposal",
      forVotes: 1000,
      againstVotes: 500,
      deadline: Math.floor(Date.now()/1000 + 3600),
      resolved: false
    });
  };

  const handleVote = async (decision: boolean) => {
    try {
      const provider = getProvider();
      const signer = provider.getSigner();
      const contract = getContract(signer);
      const tx = await contract.voteOnProposal(proposalId, decision);
      await tx.wait();
      alert("Голос учтён!");
      setHasVoted(true);
    } catch (error) {
      console.error("Error voting:", error);
    }
  };

  const handleFinalize = async () => {
    try {
      const provider = getProvider();
      const signer = provider.getSigner();
      const contract = getContract(signer);
      const tx = await contract.finalizeProposal(proposalId);
      await tx.wait();
      alert("Proposal finalized!");
    } catch (error) {
      console.error("Error finalizing proposal:", error);
    }
  };

  useEffect(() => {
    if (proposalId) {
      fetchProposalData(proposalId as string);
    }
  }, [proposalId]);

  if (!proposalData) return <Layout>Loading...</Layout>;

  return (
    <Layout>
      <h1>Proposal #{proposalData.id}</h1>
      <p>Description: {proposalData.description}</p>
      <p>For: {proposalData.forVotes}, Against: {proposalData.againstVotes}</p>
      <p>Deadline: {new Date(proposalData.deadline * 1000).toLocaleString()}</p>
      <p>Resolved: {proposalData.resolved ? "Yes" : "No"}</p>

      {/* Кнопки голосования (активны если не голосовал и не просрочено) */}
      {!hasVoted && !proposalData.resolved && Date.now()/1000 < proposalData.deadline && (
        <div>
          <button onClick={() => handleVote(true)}>Голосовать ЗА</button>
          <button onClick={() => handleVote(false)}>Голосовать ПРОТИВ</button>
        </div>
      )}

      {/* Кнопка финализации (активна, если дедлайн прошёл и не резолв) */}
      {Date.now()/1000 >= proposalData.deadline && !proposalData.resolved && (
        <button onClick={handleFinalize}>Финализировать</button>
      )}
    </Layout>
  );
};

export default ProposalDetail;