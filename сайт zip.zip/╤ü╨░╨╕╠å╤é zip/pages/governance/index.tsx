// pages/governance/index.tsx
import { NextPage } from 'next';
import Layout from '../../components/Layout';
// import ProposalCard from '../../components/ProposalCard';

const Governance: NextPage = () => {
  // Здесь вы можете загрузить список предложений из контракта, например, через метод getProposals() (если он есть),
  // или иным способом (например, вы храните ID и по каждому ID получаете структуру).

  // Простой пример заглушки
  const proposals = [
    { id: 1, description: "Proposal #1: Transfer some ETH", forVotes: 1000, againstVotes: 500, deadline: Math.floor(Date.now()/1000 + 3600) },
    { id: 2, description: "Proposal #2: Change burn rate", forVotes: 300, againstVotes: 800, deadline: Math.floor(Date.now()/1000 + 7200) },
  ];

  return (
    <Layout>
      <h1>Governance Proposals</h1>
      <a href="/governance/create">
        <button>Создать новое предложение</button>
      </a>

      <div style={{ marginTop: '2rem' }}>
        {proposals.map((proposal) => (
          <div key={proposal.id}>
            <h3>Proposal #{proposal.id}</h3>
            <p>{proposal.description}</p>
            <p>For: {proposal.forVotes} / Against: {proposal.againstVotes}</p>
            <p>Deadline: {new Date(proposal.deadline * 1000).toLocaleString()}</p>
            <a href={`/governance/${proposal.id}`}>Подробнее</a>
            <hr />
          </div>
        ))}
      </div>
    </Layout>
  );
};

export default Governance;