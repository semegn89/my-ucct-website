// pages/governance/create.tsx
import { NextPage } from 'next';
import { useState } from 'react';
import Layout from '../../components/Layout';
import { ethers } from 'ethers';
import { getContract, getProvider } from '../../lib/contract';

const CreateProposal: NextPage = () => {
  const [recipient, setRecipient] = useState('');
  const [amount, setAmount] = useState('');
  const [description, setDescription] = useState('');

  const handleCreateProposal = async () => {
    try {
      const provider = getProvider();
      const signer = provider.getSigner();
      const contract = getContract(signer);
      
      // convert amount to BigNumber (ETH)
      const parsedAmount = ethers.utils.parseEther(amount || "0");
      
      const tx = await contract.createProposal(
        recipient,
        parsedAmount,
        description,
        { value: ethers.utils.parseEther("0.1") } // залог
      );
      await tx.wait();
      alert("Proposal created successfully!");
    } catch (error) {
      console.error("Error creating proposal:", error);
    }
  };

  return (
    <Layout>
      <h1>Создание предложения</h1>
      <div>
        <label>Recipient (ETH address):</label>
        <input
          type="text"
          value={recipient}
          onChange={(e) => setRecipient(e.target.value)}
          placeholder="0xRecipient..."
        />
      </div>
      <div>
        <label>Amount (ETH):</label>
        <input
          type="text"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          placeholder="0.5"
        />
      </div>
      <div>
        <label>Description:</label>
        <textarea
          rows={4}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Опишите предложение..."
        />
      </div>
      <button onClick={handleCreateProposal}>Создать</button>
    </Layout>
  );
};

export default CreateProposal;