// pages/appeals/index.tsx

import { NextPage } from 'next';
import { useState, useEffect } from 'react';
import Layout from '../../components/Layout';
import { getBalanceOf } from '../../lib/api'; // Fixed import
import { getProvider } from '../../lib/contract';
import { ethers } from 'ethers';
import {
  UserIcon,
  DocumentTextIcon,
  CheckCircleIcon,
} from '@heroicons/react/outline';

const Appeals: NextPage = () => {
  const [account, setAccount] = useState<string | null>(null);
  const [balance, setBalance] = useState<string>('0');
  const [totalSupply, setTotalSupply] = useState<string>('0');
  const [activeProposals, setActiveProposals] = useState<number>(0);
  const [activeAppeals, setActiveAppeals] = useState<number>(0);

  useEffect(() => {
    // Пример подключения к MetaMask
    if ((window as any).ethereum) {
      (window as any).ethereum
        .request({ method: 'eth_accounts' })
        .then(async (accounts: string[]) => {
          if (accounts.length > 0) {
            setAccount(accounts[0]);
            const bal = await getBalanceOf(accounts[0]); // Correct function call
            setBalance(bal);
          }
        });
    }

    // Пример получения totalSupply
    const fetchTotalSupply = async () => {
      try {
        const provider = getProvider();
        const contract = new ethers.Contract(
          '0xYourDeployedContractAddress',
          [
            {
              inputs: [],
              name: 'totalSupply',
              outputs: [
                { internalType: 'uint256', name: '', type: 'uint256' },
              ],
              stateMutability: 'view',
              type: 'function',
            },
          ],
          provider
        );
        const ts = await contract.totalSupply();
        setTotalSupply(ethers.utils.formatEther(ts));
      } catch (error) {
        console.log(error);
      }
    };
    fetchTotalSupply();
  }, []);

  return (
    <Layout>
      <section className="mb-8 text-center">
        <h1 className="text-3xl md:text-4xl font-bold mb-2">
          Апелляции (Appeals)
        </h1>
        <p className="text-gray-700 max-w-xl mx-auto">
          Здесь вы можете управлять апелляциями, вносить адреса в чёрный список
          или оспаривать несправедливые санкции.
        </p>
      </section>

      <section className="mb-10 mx-auto max-w-md bg-white/60 backdrop-blur-md shadow-md rounded-xl p-4">
        <h2 className="text-xl font-semibold mb-3 text-center">
          Краткая статистика
        </h2>
        <div className="space-y-2 text-gray-800">
          <p>
            <strong>Ваш адрес:</strong> {account ?? 'Не подключён'}
          </p>
          <p>
            <strong>Баланс UCCT:</strong> {balance}
          </p>
          <p>
            <strong>Total Supply:</strong> {totalSupply}
          </p>
          <p>
            <strong>Активные предложения:</strong> {activeProposals}
          </p>
          <p>
            <strong>Активные апелляции:</strong> {activeAppeals}
          </p>
        </div>
      </section>

      {/* Пример карточек модулей / возможностей */}
      <section>
        <h2 className="text-2xl font-semibold mb-4 text-gray-800">
          Модули (иконки для примера)
        </h2>
        <div className="grid md:grid-cols-3 gap-4">
          {/* Profile Card */}
          <div className="bg-white/60 backdrop-blur-md shadow-md rounded-xl p-4 flex flex-col">
            <div className="flex items-center mb-2">
              <UserIcon className="w-6 h-6 text-iosBlue mr-2" />
              <h3 className="font-bold">Профиль</h3>
            </div>
            <p className="text-sm text-gray-700 flex-1">
              Управляйте данными своего аккаунта и отслеживайте баланс UCCT.
            </p>
          </div>

          {/* Governance Card */}
          <div className="bg-white/60 backdrop-blur-md shadow-md rounded-xl p-4 flex flex-col">
            <div className="flex items-center mb-2">
              <DocumentTextIcon className="w-6 h-6 text-iosBlue mr-2" />
              <h3 className="font-bold">Governance</h3>
            </div>
            <p className="text-sm text-gray-700 flex-1">
              Создавайте и голосуйте за предложения, управляйте DAO.
            </p>
          </div>

          {/* Appeals Card */}
          <div className="bg-white/60 backdrop-blur-md shadow-md rounded-xl p-4 flex flex-col">
            <div className="flex items-center mb-2">
              <CheckCircleIcon className="w-6 h-6 text-iosBlue mr-2" />
              <h3 className="font-bold">Апелляции</h3>
            </div>
            <p className="text-sm text-gray-700 flex-1">
              Подавайте апелляции, вносите адреса в&nbsp;чёрный список и
              снимайте несправедливые санкции.
            </p>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Appeals;
