// pages/blacklist.tsx
import { NextPage } from 'next';
import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { getContract, getProvider } from '../lib/contract';

const Blacklist: NextPage = () => {
  const [blacklist, setBlacklist] = useState<string[]>([]);
  const [addressToManage, setAddressToManage] = useState('');

  useEffect(() => {
    // В реальном проекте нужно уметь итерироваться по всем
    // blacklisted[address] - массив или mapping?
    // Так как mapping нельзя перебрать on-chain, возможно придётся хранить события.
    // Для DEMO просто используем заглушку.
    setBlacklist(["0xAAA...", "0xBBB..."]);
  }, []);

  const handleAdd = async () => {
    if (!addressToManage) return;
    try {
      const provider = getProvider();
      const signer = provider.getSigner();
      const contract = getContract(signer);
      const tx = await contract.addToBlacklist(addressToManage);
      await tx.wait();
      alert("Address added to blacklist");
      // обновить локальный state
      setBlacklist([...blacklist, addressToManage]);
    } catch (error) {
      console.error(error);
    }
  };

  const handleRemove = async () => {
    if (!addressToManage) return;
    try {
      const provider = getProvider();
      const signer = provider.getSigner();
      const contract = getContract(signer);
      const tx = await contract.removeFromBlacklist(addressToManage);
      await tx.wait();
      alert("Address removed from blacklist");
      setBlacklist(blacklist.filter((addr) => addr !== addressToManage));
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Layout>
      <h1>Чёрный список</h1>
      <div>
        <input
          type="text"
          placeholder="0xAddress"
          value={addressToManage}
          onChange={(e) => setAddressToManage(e.target.value)}
        />
        <button onClick={handleAdd}>Добавить в ЧС</button>
        <button onClick={handleRemove}>Удалить из ЧС</button>
      </div>
      <ul>
        {blacklist.map((addr) => (
          <li key={addr}>{addr}</li>
        ))}
      </ul>
    </Layout>
  );
};

export default Blacklist;