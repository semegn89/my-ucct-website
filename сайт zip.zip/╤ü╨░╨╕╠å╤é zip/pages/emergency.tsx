// pages/emergency.tsx
import { NextPage } from 'next';
import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { getContract, getProvider } from '../lib/contract';

const Emergency: NextPage = () => {
  const [emergencyStop, setEmergencyStop] = useState(false);

  // ЧТЕНИЕ состояния emergencyStop
  const fetchEmergencyStatus = async () => {
    try {
      const provider = getProvider();
      // Для чтения -> достаточно provider
      const readContract = getContract(provider);
      const status = await readContract.emergencyStop();
      setEmergencyStop(status);
    } catch (error) {
      console.error(error);
    }
  };

  // ПЕРЕКЛЮЧЕНИЕ (запись) -> нужен signer
  const handleToggle = async () => {
    try {
      const provider = getProvider();
      const signer = provider.getSigner(); // Signer позволяет отправлять транзакции
      const writeContract = getContract(signer);
      const tx = await writeContract.toggleEmergencyStop();
      await tx.wait();
      alert('Emergency stop toggled');
      // Обновляем состояние после транзакции
      fetchEmergencyStatus();
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchEmergencyStatus();
  }, []);

  return (
    <Layout>
      <h1>Экстренная остановка</h1>
      <p>Текущее состояние: {emergencyStop ? 'Включена' : 'Выключена'}</p>
      <button onClick={handleToggle}>Переключить Emergency Stop</button>
      {emergencyStop && (
        <div style={{ color: 'red', marginTop: '1rem' }}>
          <p>ВНИМАНИЕ: многие функции dApp недоступны, пока режим включен!</p>
        </div>
      )}
    </Layout>
  );
};

export default Emergency;