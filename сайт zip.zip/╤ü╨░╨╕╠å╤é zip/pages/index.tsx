// pages/index.tsx
import { NextPage } from 'next';
import { useState, useEffect } from 'react';
import Layout from '../components/Layout';  // <-- один уровень вверх
import { getBalanceOf } from '../lib/api';
import { getProvider } from '../lib/contract';
import { ethers } from 'ethers';
// import a specific icon if needed, e.g.:
// import { HomeIcon } from '@heroicons/react/outline'
// or remove the line if no icon is used
const Home: NextPage = () => {
  const [account, setAccount] = useState<string | null>(null);
  const [balance, setBalance] = useState<string>('0');
  const [totalSupply, setTotalSupply] = useState<string>('0');
  const [activeProposals, setActiveProposals] = useState<number>(0);
  const [activeAppeals, setActiveAppeals] = useState<number>(0);

  useEffect(() => {
    // Проверка, есть ли уже подключенный аккаунт
    if ((window as any).ethereum) {
      (window as any).ethereum
        .request({ method: 'eth_accounts' })
        .then(async (accounts: string[]) => {
          if (accounts.length > 0) {
            setAccount(accounts[0]);
            const bal = await getBalanceOf(accounts[0]);
            setBalance(bal);
          }
        });
    }

    // Пример получения totalSupply (если метод в ABI)
    const fetchTotalSupply = async () => {
      try {
        const provider = getProvider();
        const contract = new ethers.Contract(
          '0xYourDeployedContractAddress',
          [
            {
              inputs: [],
              name: 'totalSupply',
              outputs: [
                { internalType: 'uint256', name: '', type: 'uint256' },
              ],
              stateMutability: 'view',
              type: 'function',
            },
          ],
          provider
        );
        const ts = await contract.totalSupply();
        setTotalSupply(ethers.utils.formatEther(ts));
      } catch (error) {
        console.log(error);
      }
    };
    fetchTotalSupply();
  }, []);

  return (
    <Layout>
      <h1>UCCT Dashboard</h1>
      <p>Добро пожаловать в UnifiedCryptoCourtToken DApp</p>

      {account && (
        <div>
          <p>Ваш адрес: {account}</p>
          <p>Баланс UCCT: {balance}</p>
        </div>
      )}

      <p>Общее количество токенов (totalSupply): {totalSupply}</p>
      <p>Число активных предложений: {activeProposals}</p>
      <p>Число активных апелляций: {activeAppeals}</p>

      <h2>Как использовать?</h2>
      <ul>
        <li>Подключите свой MetaMask кошелёк</li>
        <li>Перейдите в раздел Governance для предложений</li>
        <li>Апелляции — в разделе Appeals</li>
      </ul>
    </Layout>
  );
};

export default Home;