// pages/events.tsx
import { NextPage } from 'next';
import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { getProvider } from '../lib/contract';
import { ethers } from 'ethers';

const EventsPage: NextPage = () => {
  const [events, setEvents] = useState<any[]>([]);

  // Пример чтения логов события "ProposalCreated" из контракта
  // В реальном проекте потребуется полный ABI и фильтры
  const fetchEvents = async () => {
    const provider = getProvider();
    const contractAddress = "0xYourDeployedContractAddress";
    const abi = [
      {
        "anonymous": false,
        "inputs": [
          { "indexed": false, "internalType": "uint256", "name": "proposalId", "type": "uint256" },
          { "indexed": true, "internalType": "address", "name": "proposer", "type": "address" },
          { "indexed": false, "internalType": "uint256", "name": "snapshotId", "type": "uint256" }
        ],
        "name": "ProposalCreated",
        "type": "event"
      }
    ];

    const contract = new ethers.Contract(contractAddress, abi, provider);
    const filter = contract.filters.ProposalCreated();
    const logs = await contract.queryFilter(filter, 0, "latest");

    const parsedEvents = logs.map((log: any) => {
      const parsed = contract.interface.parseLog(log);
      return {
        proposalId: parsed.args.proposalId.toString(),
        proposer: parsed.args.proposer,
        snapshotId: parsed.args.snapshotId.toString(),
        blockNumber: log.blockNumber,
      };
    });
    setEvents(parsedEvents);
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  return (
    <Layout>
      <h1>История / События</h1>
      <button onClick={fetchEvents}>Обновить</button>
      <ul>
        {events.map((evt, index) => (
          <li key={index}>
            [Block #{evt.blockNumber}] ProposalCreated: ID = {evt.proposalId}, proposer = {evt.proposer}, snapshot = {evt.snapshotId}
          </li>
        ))}
      </ul>
    </Layout>
  );
};

export default EventsPage;