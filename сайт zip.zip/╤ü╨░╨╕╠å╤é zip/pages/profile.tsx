// pages/profile.tsx
import { NextPage } from 'next';
import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import { getBalanceOf } from '../lib/api';
import { ethers } from 'ethers';
import { getContract, getProvider } from '../lib/contract';

const Profile: NextPage = () => {
  const [account, setAccount] = useState<string | null>(null);
  const [balance, setBalance] = useState<string>('0');
  const [karma, setKarma] = useState<number>(0);
  const [isBlacklisted, setIsBlacklisted] = useState<boolean>(false);
  const [likeAddress, setLikeAddress] = useState<string>('');

  // ЧТЕНИЕ данных о профиле (баланс, карма, blacklisted)
  const fetchProfileData = async (userAddress: string) => {
    // Получаем баланс из вашего api.ts
    const bal = await getBalanceOf(userAddress);
    setBalance(bal);

    // Для чтения кармы/blacklisted достаточно provider
    const provider = getProvider();
    const readContract = getContract(provider);

    // Читаем карму
    try {
      const karmaBN: ethers.BigNumber = await readContract.karma(userAddress);
      setKarma(karmaBN.toNumber());
      console.log('User karma =', karmaBN.toString());
    } catch (error) {
      console.error('Ошибка получения кармы:', error);
    }

    // Читаем blacklisted
    try {
      const blacklistedValue = await readContract.blacklisted(userAddress);
      setIsBlacklisted(blacklistedValue);
    } catch (error) {
      console.error('Ошибка проверки blacklist:', error);
    }
  };

  // ОТПРАВКА лайка (запись) -> нужен signer
  const handleLike = async () => {
    if (!account || !likeAddress) return;
    try {
      const provider = getProvider();
      const signer = provider.getSigner();
      const writeContract = getContract(signer);

      // like(...) это транзакция
      const tx = await writeContract.like(likeAddress);
      await tx.wait();
      alert(`Вы отправили лайк на адрес ${likeAddress}!`);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    if ((window as any).ethereum) {
      (window as any).ethereum
        .request({ method: 'eth_accounts' })
        .then((accounts: string[]) => {
          if (accounts.length > 0) {
            setAccount(accounts[0]);
            // Сразу получаем профиль
            fetchProfileData(accounts[0]);
          }
        });
    }
  }, []);

  return (
    <Layout>
      <h1>Мой профиль</h1>
      {account ? (
        <div>
          <p>Адрес: {account}</p>
          <p>Баланс UCCT: {balance}</p>
          <p>Карма: {karma}</p>
          <p>
            Статус в чёрном списке:{' '}
            {isBlacklisted ? 'Да' : 'Нет'}
          </p>
          <div className="
               p-4
               mb-4
               bg-white/60
               backdrop-blur-md
                shadow-md
               rounded-xl
           ">
            <h2 className="text-lg font-semibold mb-2">Ваш профайл</h2>
           {/* ... */}
          </div>
          <div style={{ marginTop: '1rem' }}>
            <h3>Отправить лайк</h3>
            <input
              type="text"
              placeholder="0xReceiverAddress"
              value={likeAddress}
              onChange={(e) => setLikeAddress(e.target.value)}
            />
            <button onClick={handleLike}>Отправить лайк (1 UCCT)</button>
          </div>
        </div>
      ) : (
        <p>Подключите кошелёк</p>
      )}
    </Layout>
  );
};

export default Profile;