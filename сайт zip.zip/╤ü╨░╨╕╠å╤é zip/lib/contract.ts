import { ethers } from 'ethers';

export const UCCT_CONTRACT_ADDRESS = '0xYourDeployedContractAddress';
export const UCCT_ABI = [
  // ...
];

// Возвращаем ethers.providers.Web3Provider или ethers.providers.JsonRpcProvider
export function getProvider() {
  if (typeof window !== 'undefined' && (window as any).ethereum) {
    return new ethers.providers.Web3Provider((window as any).ethereum);
  } else {
    return new ethers.providers.JsonRpcProvider('https://mainnet.infura.io/v3/your-infura-key');
  }
}

/**
 * getContract может принимать:
 *  - signerOrProvider: ethers.Signer | ethers.providers.Provider
 *    (а если undefined, тогда используем fallback через getProvider())
 */
export function getContract(
  signerOrProvider?: ethers.Signer | ethers.providers.Provider
) {
  if (!signerOrProvider) {
    // Если ничего не передали, берём default provider
    signerOrProvider = getProvider();
  }
  return new ethers.Contract(
    UCCT_CONTRACT_ADDRESS,
    UCCT_ABI,
    signerOrProvider
  );
}