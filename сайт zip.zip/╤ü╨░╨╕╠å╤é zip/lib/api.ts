// lib/api.ts
import { ethers } from 'ethers';
import { getContract, getProvider } from './contract';

// Подключение кошелька:
export async function connectWallet(): Promise<string | null> {
  try {
    if (!(window as any).ethereum) {
      alert("MetaMask not detected!");
      return null;
    }
    const [account] = await (window as any).ethereum.request({ method: 'eth_requestAccounts' });
    return account;
  } catch (error) {
    console.error(error);
    return null;
  }
}

// Получить баланс UCCT
export async function getBalanceOf(address: string): Promise<string> {
  const contract = getContract();
  const balanceBN = await contract.balanceOf(address);
  return ethers.utils.formatEther(balanceBN);
}

// Пример: создать предложение
export async function createProposal(
  signer: ethers.Signer,
  recipient: string,
  amount: number,
  description: string
) {
  const contract = getContract(signer);
  const tx = await contract.createProposal(
    recipient,
    ethers.utils.parseEther(amount.toString()),
    description,
    {
      value: ethers.utils.parseEther("0.1"), // Депозит
    }
  );
  // Ждём подтверждения
  return tx.wait();
}

// И т.д. — добавляйте остальные методы (voteOnProposal, finalizeProposal, etc.)