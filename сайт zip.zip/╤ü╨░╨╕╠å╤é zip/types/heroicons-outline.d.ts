declare module '@heroicons/react/outline' {
  import { FC, SVGProps } from 'react';

  export const UserIcon: FC<SVGProps<SVGSVGElement>>;
  export const DocumentTextIcon: FC<SVGProps<SVGSVGElement>>;
  export const CheckCircleIcon: FC<SVGProps<SVGSVGElement>>;
  // при необходимости добавляйте ещё иконки
}